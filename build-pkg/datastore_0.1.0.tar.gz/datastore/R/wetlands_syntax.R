#' @name grasslands
#' 
#' @docType data
#' 
#' @title Grasslands from Temuco, Chile
#' 
#' @format A [vegtable-class] object.
#' 
#' @details 
#' Describe.
#' 
#' @references 
#' \bold{San Martín C et al. (1998).} 
#' La vegetación de lagunas primaverales en las cercanías de Temuco
#' (Cautín, Chile).
#' \emph{Acta Botanica Malacitana} 23: 99--120.
#' 
"grasslands"
